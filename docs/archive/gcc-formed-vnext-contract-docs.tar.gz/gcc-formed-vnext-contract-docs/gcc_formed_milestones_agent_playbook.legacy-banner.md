# Legacy notice for `gcc_formed_milestones_agent_playbook.md`

Insert the following block at the top of the existing playbook until the file is removed or superseded:

> **Legacy notice**
>
> This file reflects the pre-vNext delivery model and is kept only as historical reference.
> It is **not** the planning authority for current vNext work.
>
> The authoritative order is:
>
> 1. `SUPPORT-BOUNDARY.md`
> 2. `EXECUTION-MODEL.md`
> 3. current ADRs
> 4. current contract docs
> 5. GitHub Issues / Sub-issues / Project fields
>
> If this file conflicts with those documents, this file loses.
